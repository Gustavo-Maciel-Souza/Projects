

package modelo;


public abstract class absPropriedades
{
    public String numero;
    public int num;
    public String mensagem;
    public String resposta;
}
