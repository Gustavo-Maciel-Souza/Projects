package modelo;

public class Estaticos
{
    public static String mensagem;
}
