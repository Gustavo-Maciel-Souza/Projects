package fatorial;

import apresentacao.frmPrincipal;

public class Fatorial
{
    public static void main(String[] args)
    {
        frmPrincipal frmP = new frmPrincipal(null, true);
        frmP.setVisible(true);
    }
    
}
