package modelo;

public interface intMetodos
{
    public void executar();
}
