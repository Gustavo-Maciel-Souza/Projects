package modelo;

public class Estaticos
{
    public static String mensagem;
    public static String numero;
    public static String resposta;
    public static Integer num;
}
