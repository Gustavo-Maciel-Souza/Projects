package modelo;

public interface intMetodos 
{
    void executar();
}
