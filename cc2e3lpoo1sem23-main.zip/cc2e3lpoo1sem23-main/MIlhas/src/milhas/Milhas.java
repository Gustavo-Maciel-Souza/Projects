
package milhas;

import apresentacao.frmPrincipal;


public class Milhas 
{
    public static void main(String[] args) 
    {
        frmPrincipal frmP = new frmPrincipal(null, true);
        frmP.setVisible(true);
    }
}
