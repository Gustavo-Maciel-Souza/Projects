package tipostriangulos;

import apresentacao.frmPrincipal;

public class TiposTriangulos
{

    public static void main(String[] args)
    {
        frmPrincipal frmP = new frmPrincipal(null, true);
        frmP.setVisible(true);
    }
    
}
