/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author Rever
 */
public abstract class Propriedades
{

    public Double num1;
    public Double num2;
    public String operacao;
    public Double resultado;
    public String resposta;
    public String numero1;
    public String numero2;
    public String mensagem;

}

