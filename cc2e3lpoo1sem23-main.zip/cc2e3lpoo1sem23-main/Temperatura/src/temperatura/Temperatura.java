package temperatura;

import Apresentacao.frmPrincipal;

public class Temperatura
{
    public static void main(String[] args)
    {
        frmPrincipal frmP = new frmPrincipal(null, true);
        frmP.setVisible(true);
    }
    
}
