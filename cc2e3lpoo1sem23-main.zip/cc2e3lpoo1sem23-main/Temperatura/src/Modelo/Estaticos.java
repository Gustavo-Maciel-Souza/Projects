package Modelo;

public class Estaticos
{
    public static String mensagem;
}
