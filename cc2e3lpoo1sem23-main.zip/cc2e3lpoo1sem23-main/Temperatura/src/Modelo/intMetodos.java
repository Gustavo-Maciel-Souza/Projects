package Modelo;

public interface intMetodos 
{
    void executar();
}
