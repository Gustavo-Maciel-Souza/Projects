package numeroprimo;

import apresentacao.frmPrincipal;

public class NumeroPrimo
{
    public static void main(String[] args)
    {
        frmPrincipal frmP = new frmPrincipal(null, true);
        frmP.setVisible(true);
    }
    
}
