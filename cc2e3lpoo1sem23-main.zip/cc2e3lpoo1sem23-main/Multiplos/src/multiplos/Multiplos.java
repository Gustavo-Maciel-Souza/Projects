
package multiplos;

import apresentacao.frmPrincipal;


public class Multiplos {


    public static void main(String[] args) 
    {
        frmPrincipal frmP = new frmPrincipal(null, true);
        frmP.setVisible(true);
    }

}
